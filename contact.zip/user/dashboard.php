<?php
    echo "Welcome to User Dashboard Area.";
?>